import { Component, OnInit } from '@angular/core';

import { Platform, NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { CategoriasService } from './services/categorias.service';
import { UsuariosService } from './services/usuarios.service';
import { Router } from '@angular/router';
import { IUsuario } from './interfaces/UsuarioInterface';
import { ConfigService } from './services/config.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  
  categorias: any;
  usuario: IUsuario;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private categoriasService: CategoriasService,
    private uService: UsuariosService,
    private navCtrl: NavController,
    private router: Router,
    private configService: ConfigService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  mostrarProductos(g){
    console.log(g);
    this.router.navigate(["/categorias",{ outlets: {'primary': ["productos", g] }} ]).then(nav => {
      console.log(nav);
    }, err => {
      console.log(err)
  }

  async ionViewWillEnter (){
    console.log('datos de usuario');
    this.uService.userStorageObservable
      .subscribe ( data => {
        this.usuario = data;
        console.log (this.usuario );
      })
    
  }
  async ngOnInit() {

    this.uService.userStorageObservable
      .subscribe ( data => {
        this.usuario = data;
        console.log (this.usuario );
      });
    }
  

  async getUser() {
      console.log (this.usuario);
  }
}
