import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ICategoria, IProducto, MsnApiCategorias } from 'src/app/interfaces/ProductosInterface';
import { CategoriasService } from 'src/app/services/categorias.service';
import { UsuariosService } from '../../services/usuarios.service';
import { MsnApiProductos } from '../../interfaces/ProductosInterface';
import { ProductosService } from '../../services/filters/productos.service';
import { ConfigService } from '../../services/config.service';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.scss'],
})
export class ProductosComponent implements OnInit {
  public respuesta: MsnApiProductos;
  public categoria: ICategoria;
  public idcategoria: string;
  public productos: IProducto[];
  public images = `${URL}/img/productos`;
  public producto: IProducto = {
    Nombre: '',
    PrecioVenta: 0
  }; 

  constructor(private route: ActivatedRoute,  private router: Router, public filterPService: ProductosService,
              private cService: CategoriasService, public uService: UsuariosService,
              public configService: ConfigService) { 
    
    this.idcategoria = this.route.snapshot.paramMap.get('categoria');
    console.log(this.idcategoria);
    this.router.navigate(['/filters', { outlets: { secondary: ['productos'] } }]);
  }
 
  async ngOnInit() {
    this.respuesta = await this.cService.getProductosCategoria(this.idcategoria);
    console.log(this.respuesta);
    if (this.respuesta.status == 'success'){
      this.productos = this.respuesta.data;
    }

    this.cService.productosStorageObservable
      .subscribe (respuesta => {
        this.productos = respuesta;
        console.log (this.productos);
    });
      
    this.filterPService.productosStorageObservable
    .subscribe (respuesta => {
      this.productos = respuesta;
      console.log (this.productos);
    });

    this.uService.userStorageObservable
      .subscribe ( data => {
    //    this.rol = data.rol;
        
      });
  }

  editar(){
    console.log(this.producto);
  }
}