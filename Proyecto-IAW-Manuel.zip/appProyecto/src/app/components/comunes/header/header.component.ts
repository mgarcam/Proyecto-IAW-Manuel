import { Component, OnInit, Input } from '@angular/core';
import { IRuta } from '../../../interfaces/BreadInterfaces';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @Input('seccion') seccion: string;
  @Input('items') items: IRuta[];
   
  constructor() { }

  ngOnInit(): void {
    console.log(this.items);
   }
}
