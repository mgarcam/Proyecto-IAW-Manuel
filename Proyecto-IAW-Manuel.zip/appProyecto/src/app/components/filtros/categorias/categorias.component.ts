import { Component, OnInit } from '@angular/core';
import { CategoriasService } from '../../../services/categorias.service';
import { ICategoria } from '../../../interfaces/ProductosInterface';

@Component({
  selector: 'app-categorias',
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.scss'],
})
export class CategoriasComponent implements OnInit {
  public categorias: ICategoria;
  
  constructor(private categoriasService: CategoriasService) { 
  }
  async ionViewWillEnter(){    
  }
  async ngOnInit() {    
  }
}
