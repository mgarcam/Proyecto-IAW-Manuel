import { Component, OnInit } from '@angular/core';
import { CategoriasService } from '../../../services/categorias.service';
import { ICategoria } from '../../../interfaces/ProductosInterface';
import { ProductosService } from '../../../services/filters/productos.service';
import { Platform } from '@ionic/angular';
import { IFiltrosProdcutos } from '../../../interfaces/FiltrosInterfaces';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrls: ['./productos.component.scss'],
})
export class ProductosComponent implements OnInit {
 
  public categorias: ICategoria;
  public items: string[] = [];
  public precio = 50;
  public rangeVal: string;
  public IFiltros: IFiltrosProdcutos = {
    precios: [],
    categorias: []
  };
  constructor(public platform: Platform,
              private categoriasService: CategoriasService, private filterPService: ProductosService) {
    this.platform.ready().then( () => {
      this.rangeVal = "50";
    });

  }
  async ionViewWillEnter(){
    let respuesta = await this.categoriasService.getCategorias();
    this.categorias = respuesta.data;
    console.log (respuesta);
  }
  changeRange(precio) {
   console.log(precio.detail.value.lower,':', precio.detail.value.upper);
   this.IFiltros.precios[0] = precio.detail.value.lower;
   this.IFiltros.precios[1] = precio.detail.value.upper;

  }
  async ngOnInit() {
    let respuesta = await this.categoriasService.getCategorias();
    this.categorias = respuesta.data;
    console.log (respuesta);
  }

  async selectcategoria(categoria, pos){
    console.log(categoria, pos);
    //
    let i = this.items.indexOf(categoria);
    if ( i == -1 ){
      this.items.push(categoria);
    }else {
      this.items.splice( i, 1 );
    }
    console.log(this.items);
  }

  async aplicar(){
     this.IFiltros.categorias = this.items;
      console.log (this.IFiltros);
      let respuesta = await this.filterPService.getFilter(this.IFiltros);
      this.items = [];
  }
}
