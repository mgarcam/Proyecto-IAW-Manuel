import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoriasService } from 'src/app/services/categorias.service';
import { ICategoria } from '../../interfaces/ProductosInterface';
import { environment } from '../../../environments/environment.prod';
import { IRuta } from 'src/app/interfaces/BreadInterfaces';
import { UsuariosService } from '../../services/usuarios.service';
import { NavController } from '@ionic/angular';
import { ConfigService } from '../../services/config.service';
const URL = environment.url;

@Component({
  selector: 'app-categorias',
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.scss'],
})
export class CategoriasComponent implements OnInit {
  categorias: ICategoria;
  categoria: any;
  rol: string;
  tipo: string;
  isActiveConfig: boolean = false;
  isClickConfig: boolean = false;
  isAdmin: boolean = false;
  public images = `${URL}/img/categorias`;
  public bread: IRuta[] = [
    { nombre: 'Categorias', clase: 'active', link: [ '/categorias'] }
  ];
  constructor(public uService: UsuariosService,  private categoriasService: CategoriasService,
              private navCtrl: NavController, 
              private router: Router, private route: ActivatedRoute,
              public configService: ConfigService ) {
    this.categoria = this.route.snapshot.paramMap.get('id');
    console.log (this.categoria);
    console.log(this.categoriasService.getCategorias());
   }

  async ngOnInit() {
    let respuesta = await this.categoriasService.getCategorias();
    if (respuesta.status == 'success'){
      this.categorias = respuesta.data;
      console.log('isAdmin', this.configService.isAdmin, this.configService.iconEdit, this.configService.isClickConfig);
      console.log(this.categorias);
    }
  }
  pulsar(){
    this.configService.edicion();
  }
  async ionViewWillEnter (){

    console.log('filtros');
    let respuesta = await this.categoriasService.getCategorias();
    if (respuesta.status == 'success'){
      this.categorias = respuesta.data;
    }
  }

  productos (categoria){
    console.log (categoria);
  }
}
