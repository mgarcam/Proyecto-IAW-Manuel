import { NgModule } from '@angular/core';
import { ComunesModule } from '../comunes/comunes.module';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { CategoriasRoutingModule } from './categorias-routing.module';
import { CategoriasComponent } from './categorias.component';
import { ProductoscategoriaComponent } from './productoscategoria/productoscategoria.component';
import { PipesModule } from '../../pipes/pipes.module';
import { ProductosModule } from '../productos/productos.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [CategoriasComponent, ProductoscategoriaComponent],
  exports: [CategoriasComponent, ProductoscategoriaComponent],
  imports: [
    ComunesModule,
    CommonModule,
    IonicModule,
    CategoriasRoutingModule,
    PipesModule,
    ProductosModule
  ]
})
export class CategoriasModule { }
