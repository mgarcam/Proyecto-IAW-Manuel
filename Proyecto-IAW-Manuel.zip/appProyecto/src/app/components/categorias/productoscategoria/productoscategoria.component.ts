import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoriasService } from '../../../services/categorias.service';
import { IProducto, ICategoria, MsnApiCategorias } from '../../../interfaces/CategoriasInterface';
import { environment } from '../../../../environments/environment.prod';
import { IRuta } from '../../../interfaces/BreadInterfaces';

const URL = environment.url;

@Component({
  selector: 'app-productoscategoria',
  templateUrl: './productoscategoria.component.html',
  styleUrls: ['./productoscategoria.component.scss'],
})
export class ProductoscategoriaComponent implements OnInit {

  public respuesta: MsnApiGamas;
  public idgama: string;
  public gama: ICategoria;
  public productos: IProducto[];
  public images = `${URL}/img/productos`;

  public bread: IRuta[] = [
    { nombre: 'Categorias', clase: 'active', link: [ '/categorias'] }
  ];

  constructor(private route: ActivatedRoute, 
              private cService: CategoriasService) { }

  async ngOnInit() {
    this.idcategoria = this.route.snapshot.paramMap.get('id');
    this.bread.push({ nombre: this.idcategoria, clase: '', link: [] });
  }
}
