import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoriasComponent } from './categorias.component';
import { ProductoscategoriaComponent } from './productoscategorias/productoscategorias.component';
import { ProductosComponent } from '../productos/productos.component';

const routes: Routes = [
  { path: '', component: CategoriasComponent, outlet: 'primary' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CategoriasRoutingModule { }
