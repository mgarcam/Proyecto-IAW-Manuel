interface IPrecio {
    min: number;
    max: number;
}

export interface IFiltrosProdcutos {
    categorias: string[];
    precios: number[];
}
