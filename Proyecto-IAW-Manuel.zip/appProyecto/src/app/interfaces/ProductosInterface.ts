export interface IProducto {
    CodigoProducto?: number;
    Nombre?: string;
    Proveedor?: string;
    LimiteCredito?: number;
    Descripcion?: string;
    CantidadEnStock?: number;
    PrecioVenta?: number,
    PrecioProveedor?: number,
    imagen?: string;
    Categoria?: ICategoria;
}
export interface ICategoria {
    Categoria: string;
    Descripcion: string;
    Imagen: string;
    productos?: IProducto[]
}

type CCategorias = ICategoria[] | ICategoria;
export interface MsnApiCategorias {
    status?: string;
    message?: string;
    errors?: string;
    code?: number;
    data?: ICategoria;
}
export interface MsnApiProductos {
    status?: string;
    message?: string;
    errors?: string;
    code?: number;
    data?: IProducto[];
}


