export interface IRuta {
    nombre: string;
    clase: string;
    link: string[];
}

