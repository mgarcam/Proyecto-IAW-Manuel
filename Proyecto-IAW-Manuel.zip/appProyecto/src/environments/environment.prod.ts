export const environment = {
  production: true,
  url: 'http://proyecto.test'
};
