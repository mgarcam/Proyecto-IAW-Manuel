<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class producto extends Model
{
    use HasFactory;
    protected $table = 'productos';
    protected $primarykey = 'CodigoProducto';

    public function micategoria(){
        return $this->belongsTo(categoria::class, 'Categoria','Categoria');
    }
}
