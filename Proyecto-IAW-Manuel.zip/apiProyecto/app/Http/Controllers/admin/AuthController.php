<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;


class AuthController extends Controller
{
    public function signup1(Request $request)
    {
        $user = new User([
            'id'  => $request->user_id,
            'name'     => $request->name,
            'surname'  => $request->surname,
            'rol'      => $request->rol,
            'email'    => $request->email,
            'password' => bcrypt($request->password),
            'image'    => $request->image,
        ]);

        return response()->json([
            'user' => $request->all(),
            'message' => 'Usuario creado correctamente'], 201);

    }

    public function signup(Request $request)
    {
        $rules = [
            'id'       => 'required|integer',
            'rol'      => 'required',
            'name'     => 'required',
            'surname'  => 'required',
            'email'    => 'required',
            'password' => 'required',
            'image'    => 'required',
        ];

        $input = $request->all();
        $validator = Validator::make($input, $rules);

        if ($validator->fails()){
            return response()->json([
                'status' => 'error',
                'message' => 'Error en la validación de los datos',
                'errors'=> $validator->errors()
            ], 200);
        }

       // $user = New user([

        $user = User::create(array(
            'id'       => $request->input('id'),
            'rol'      => $request->input('rol'),
            'name'     => $request->input('name'),
            'surname'  => $request->input('surname'),
            'email'    => $request->input('email'),
            'password' => bcrypt($request->password),
            'image'    => $request->input('image')
        ));

        $user['id'] = (int)($request->input('id'));
        $user->save();

        $tokenAuth = $user->createToken('task api');

        $token = $tokenAuth->accessToken;
        $tokenAuth->token->user_id = $user['id'];
        $tokenAuth->token->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Usuario creado correctamente!'], 201);

    }

    public function login1(){
        echo "login";
        if (auth()->attempt(request()->input())){
            $user = auth()->user();
            $success['token']=$user
                ->createToken('Passport api')
                ->accessToken;

            return response()->json($success, 200);
        }else{
            return response()->json(['error'=> 'Unatohorized'], 401);
        }
    }

    public function login(Request $request){

        #Paso1-. validamos el  email/pasword que viene del password
        $request->validate([
            'email' => 'required|string',
            'password' => 'required|string'
        ]);

        $credentials = request(['email', 'password']);

        if(!Auth::attempt($credentials)){
            return response()->json([
                'status' => 'error',
                'message' => 'Credenciales erróneas', 'code' => 401
            ]);
        }

        $user = Auth::user();

        $tokenAuth = $user->createToken('Personal Access Token');

        $token = $tokenAuth->accessToken;

        $tokenAuth->token->user_id = $user['id'];

        $tokenAuth->token->expires_at = Carbon::now()->addWeeks(1);

        $tokenAuth->token->save();

        $usuario = User::with('cliente')->find($user->id);

        return response()->json([
           'status' => 'success',
           'user' => $usuario,
           'token' => [
                'access_token' => $token,
                'token_type' => 'Bearer ',
                'expires_at' => Carbon::parse($tokenAuth->token->expires_at)->toDateTimeString()
           ]

       ]);

    }

    public function getUser(Request $request) {

        $user = Auth::user();
        $usuario = User::where('id', $user->id)->with('cliente')->get();
        $usuario = User::with('cliente')->find($user->id);
        return  response()->json([
            'status' => 'success',
            'message' => 'Datos del usuario',
            'code' => 401,
            'user' => $usuario
        ]);
    }

    public function logout(Request $request){
        $request->user()->token()->revoke();
        return  response()->json([
            'message' => 'Sesión finalizada correctamente',
        ]);
    }
}
