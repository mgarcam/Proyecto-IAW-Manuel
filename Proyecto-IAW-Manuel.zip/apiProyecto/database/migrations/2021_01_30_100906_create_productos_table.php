<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('productos', function (Blueprint $table) {
            $table->string('id_producto', 4)->primary();
            $table->string('Nombre', 20);
            $table->string('cod_categoria', 7);
            $table->string('Info', 255);
            $table->string('PVP', 10);
            $table->string('Imagen', 30);
            $table->string('Referencia', 10);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('productos');
    }
}
