
<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\ProductosController;


Route::group(['middleware' => 'auth:api'], function () {
    Route::get('admin/productos', [ProductosController::class,'index']);
    Route::get('admin/productos/{producto}', [ProductosController::class,'show']);
    Route::group(['middleware' => 'rol.admin'], function () {
        Route::post('admin/productos', [ProductosController::class,'store']);
        Route::put('admin/productos/{producto}', [ProductosController::class,'update']);
        Route::delete('admin/productos/{producto}', [ProductosController::class,'destroy']);
    });
});