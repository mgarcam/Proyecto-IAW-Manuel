<?php

use App\Http\Controllers\admin\CategoriasController;
use App\Http\Controllers\admin\ProductosController;
use App\Http\Controllers\admin\UsuariosController;
use App\Http\Controllers\admin\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
//Route::resource('admin/categorias', CategoriasController::class);
Route::resource('admin/usuarios', UsuariosController::class);

Route::post('login', [AuthController::class, 'login']);
Route::post('register', [AuthController::class, 'signup']);
/*
Route::get('user', [AuthController::class, 'getUser'])
    ->middleware('auth:api');

Route::post('logout', [AuthController::class, 'logout'])
    ->middleware('auth:api');
*/
Route::post('categorias', [CategoriasController::class, 'categorias']);

Route::group(['middleware' => 'auth:api'], function () {
    Route::post('logout', [AuthController::class, 'logout']);
    Route::get('user', [AuthController::class, 'getUser']);

  //  Route::get('admin/categorias', [CategoriasController::class, 'index']);
  //  Route::get('admin/categorias/productos', [CategoriasController::class,'getProductos']);

});